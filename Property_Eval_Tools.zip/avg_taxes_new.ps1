﻿### AVERAGE TAXES (NEW) ###

$taxInfo = Get-Content .\avg_taxes.json | ConvertFrom-Json

$num = 0

Do { $num++
    } until ($fullState -eq $taxInfo.state[$num])